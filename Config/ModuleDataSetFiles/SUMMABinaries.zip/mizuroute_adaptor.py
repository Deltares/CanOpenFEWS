
""""

MizuRoute Model Adaptor for Delft-FEWS 

This script is used to run MizuRoute in Delft-FEWS

Scripted by Dave Casson, Darri Eythorsson

"""

import os
import xarray as xr
import logging

from pathlib import Path
import subprocess

from adaptor_utils import *

# Get the absolute path of the directory containing the current file
current_file_directory = os.path.dirname(os.path.abspath(__file__))
# Change the current working directory to the directory of the current file
os.chdir(current_file_directory)

def update_mizuroute_control_file(file_path, settings_to_update=None):
    with open(file_path, 'r') as f:
        lines = f.readlines()

    updated_lines = []
    for line in lines:
        if settings_to_update:
            for key, value in settings_to_update.items():
                if line.strip().startswith(f'<{key}>'):
                    padding = len(line.split('<')[0])  
                    padded_key = f"<{key}>".ljust(30)  # Pad the key to 20 characters
                    padded_value = _pad_string(value)
                    comment = line.split('!')[-1].strip() if '!' in line else ''
                    line = f"{' ' * padding}{padded_key}{padded_value}! {comment}\n"
                    break

        updated_lines.append(line)

    with open(file_path, 'w') as f:
        f.writelines(updated_lines)

def _pad_string(string, pad_to=20):
    return f"{string:{pad_to}}"

def update_mizuroute_with_runinfo(run_info_dict, control_file, cwd):
    
    logger.info(f'Updating mizuroute run settings')
 
 
    sim_start_raw = run_info_dict['data_vars']['start_time']['data']
    sim_end_raw = run_info_dict['data_vars']['end_time']['data']
    #case_name =  run_info_dict['data_vars']['properties']['attrs']['Model']

    ancil_dir = os.path.join(cwd,'mizuroute/')
    input_dir = os.path.join(cwd,'output/')
    output_dir = os.path.join(cwd,'output/')

    sim_start = sim_start_raw.strftime('%Y-%m-%d %H:%M:%S')
    sim_end = sim_end_raw.strftime('%Y-%m-%d %H:%M:%S')

    settings_to_update= {
        "sim_start" : sim_start,
        "sim_end" : sim_end,
        "ancil_dir": ancil_dir, 
        "input_dir": input_dir,
        "output_dir": output_dir   
        }

    update_mizuroute_control_file(control_file, settings_to_update)

    logger.info(f'Updating model simulation start time to {sim_start}')
    logger.info(f'Updating model simulation end time to {sim_end}')

    return
def post_process_output(output_ds, cwd):
    """Post-processes the MizuRoute output dataset, combining 'seg' and 'hru' into 'ndata' and adding metadata to 'basinID'."""
    logger.info("Starting post-processing of the output dataset")

    # If both 'seg' and 'hru' exist, we need to merge them into 'ndata'
    if 'seg' in output_ds.dims and 'hru' in output_ds.dims:
        logger.info("Both 'seg' and 'hru' dimensions found. Merging into 'ndata'.")
        
        # Concatenate the variables along a new 'ndata' dimension
        output_ds = output_ds.rename_dims({'seg': 'ndata', 'hru': 'ndata'})
        logger.info("Renamed 'seg' and 'hru' dimensions to 'ndata'.")
    
    elif 'seg' in output_ds.dims:
        output_ds = output_ds.rename_dims({'seg': 'ndata'})
        logger.info("Renamed 'seg' dimension to 'ndata'.")
    
    elif 'hru' in output_ds.dims:
        output_ds = output_ds.rename_dims({'hru': 'ndata'})
        logger.info("Renamed 'hru' dimension to 'ndata'.")

    # Ensure that all variables are mapped to 'time' and 'ndata'
    for var in output_ds.data_vars:
        dims = output_ds[var].dims
        
        # Only remap variables that have 'time' and 'ndata' dimensions
        if 'time' in dims and 'ndata' in dims:
            try:
                output_ds[var] = output_ds[var].transpose('time', 'ndata')
                logger.info(f"Remapped variable {var} to dimensions ('time', 'ndata').")
            except ValueError as e:
                logger.error(f"Error remapping {var}: {e}")

    # Ensure that 'basinID' exists and map it to 'ndata' with the correct metadata
    if 'ndata' in output_ds.dims:
        if 'basinID' not in output_ds.variables:
            output_ds['basinID'] = xr.DataArray(
                output_ds['ndata'],
                dims=['ndata'],
                attrs={
                    'long_name': 'ID of HRU',
                    'cf_role': 'timeseries_id',
                    'units': '1',
                    'coordinates': 'basinID'
                }
            )
            logger.info("Created 'basinID' variable mapped to 'ndata'.")
        else:
            # Update the metadata of the existing 'basinID' variable
            output_ds['basinID'].attrs.update({
                'long_name': 'ID of HRU',
                'cf_role': 'timeseries_id',
                'units': '1',
                'coordinates': 'basinID'
            })
            logger.info("Updated metadata for 'basinID' variable.")

    # Ensure 'time' variable is only time values
    if 'time' in output_ds.dims:
        output_ds['time'] = output_ds['time']
        logger.info("Ensured 'time' variable contains only time values.")

    # Add global attributes without modifying 'time'
    output_ds.attrs['Conventions'] = 'CF-1.6'
    output_ds.attrs['featureType'] = 'timeSeries'
    logger.info("Added global attributes to the output dataset.")

    # Save the modified dataset
    output_nc = Path(cwd, 'output/mizuroute_output.nc')
    output_ds.to_netcdf(output_nc)
    logger.info(f"Post-processed output saved to {output_nc}")


def rename_state_file(directory: str, search_str: str, new_file_name: str):
    """
    Renames all files in the given directory that contain the search string in their name.

    Parameters:
    - directory (str): The path to the directory where the files are located.
    - search_str (str): The string to search for in the file names.
    - new_name_str (str): The new name string to replace the search string in the file names.
    
    Returns:
    - None
    """
    cleaned_directory = directory#.split("'")[1].strip()

    # Ensure the directory exists
    if not os.path.isdir(cleaned_directory):
        logger.error(f"Directory {cleaned_directory} does not exist.")
        return

    # Iterate through all files in the directory
    for filename in os.listdir(cleaned_directory):
        # Check if the search string is in the filename
        if search_str in filename:

            # Construct full file paths
            old_file_path = os.path.join(cleaned_directory, filename)
            new_file_path = os.path.join(cleaned_directory, new_file_name)
            # Rename the file
            os.rename(old_file_path, new_file_path)

            logger.info(f"Renamed: {filename} -> {new_file_name}")



def run_mizuroute(model_exe, control_file, log_file):
    """
    Run the mizuRoute model.

    This method executes the mizuRoute model,
    and handles any errors that occur during the run.
    """

    
    # Run mizuRoute
    mizu_command = f"{model_exe} {control_file}"

    try:
        result = subprocess.run(mizu_command, shell=True, check=True,text=True, capture_output=True)#, stdout=log_file, stderr=subprocess.STDOUT)
        if "FATAL ERROR" in result.stderr:
            logger.error(f"mizuRoute run failed with internal error: {result.stderr}")
        else:
            logger.info("mizuRoute run completed successfully.")
    except subprocess.CalledProcessError as e:
        logger.error(f"mizuRoute run failed with error: {e}")

def main():

    """Main function to run state update process"""

    # Read and assign all command line arguments and log
    cmd_line_args = get_command_line_agruments()
    cmd_options, _ = cmd_line_args.parse_args()

    # Resolve input arguments to absolute paths
    cwd = cmd_options.work_dir
    run_info_nc = Path(cmd_options.run_info_file).resolve()
    model_exe = Path(cmd_options.model_exe).resolve()
    control_file = Path(cmd_options.file_manager).resolve()
    
    """Below the paths can be set manually for testing"""
    #cwd = "/home/exouser/GitRepos/FEWS/CanOpenFEWS/Modules/SUMMA/Chena/"
    #model_exe = "/home/exouser/GitRepos/FEWS/CanOpenFEWS/Modules/SUMMA/bin/mizuroute.exe"
    #control_file = "/home/exouser/GitRepos/FEWS/CanOpenFEWS/Modules/SUMMA/Chena/mizuroute/mizuroute.control"
    #run_info_nc = Path("/home/exouser/GitRepos/FEWS/CanOpenFEWS/Modules/SUMMA/Chena/run_info.nc")

    setup_logger(cwd)

    logger.info(f'Beginning mizuroute model run from Delft-FEWS')
    #logger.info(f'Using command line options: {cmd_options}')

    #Read run info file into dictionary
    run_info_dict = read_run_info_file(run_info_nc)

    update_mizuroute_with_runinfo(run_info_dict, control_file, cwd)

    # Run pysumma
    logger.info(f'Running mizuroute')

    run_mizuroute(model_exe, control_file, './mizuroute_log.log')
    output_dir = os.path.join(cwd,"output/")
    rename_state_file(output_dir, '.h.', 'mizuroute_interim_output.nc')

    output_ds = xr.open_dataset(Path(output_dir, 'mizuroute_interim_output.nc'))
    post_process_output(output_ds, cwd)

    #rename_state_file(str(sim.manager['outputPath']), 'restart', 'state_update.nc')

    return

if __name__ == "__main__":
   
   main()


