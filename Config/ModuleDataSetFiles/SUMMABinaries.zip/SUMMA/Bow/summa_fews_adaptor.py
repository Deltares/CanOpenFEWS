
""""

SUMMA Model Adaptor for Delft-FEWS 

This script is used to run the SUMMA (Structure for Unifying Multiple Modeling Alternatives) modelling framework in Delft-FEWS

Scripted by Dave Casson

"""
import os, sys
import optparse as op
import xarray as xr
import numpy as np
import logging
import pysumma as ps
print(ps.__file__)
from pathlib import Path

# Get the absolute path of the directory containing the current file
current_file_directory = os.path.dirname(os.path.abspath(__file__))
# Change the current working directory to the directory of the current file
os.chdir(current_file_directory)

# Define the logger
logger = logging.getLogger(__name__)

def setup_logger(cwd, log_file_name='summa_model_run.log'):
    """
    Set local log file and formatting. This function initializes a global logger
    that can be used across the entire module.
    """
    global logger

    log_file = os.path.join(cwd, log_file_name)

    # Clear existing handlers if any
    if logger.hasHandlers():
        logger.handlers.clear()

    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # Stream Handler for printing logs to console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)


    logger.addHandler(file_handler)
    logger.info(f'Log file saved to {log_file}')

def get_command_line_agruments():
    '''Function to retrieve command line arguments'''

    logger.info('Reading command lines arguments')

    cmd_line_args = op.OptionParser()
    cmd_line_args.add_option('--work-dir',        '-d',  default = os.path.dirname(os.path.abspath(__file__)))
    cmd_line_args.add_option('--run-info-file',   '-r',  default ='./run_info.nc')

    # Read summa
    cmd_line_args.add_option('--summa-exe',       '-s',  default ='../bin/summa.exe')
    cmd_line_args.add_option('--file-manager',    '-f',  default ='./settings/fileManager.txt')

    return cmd_line_args

def read_run_info_file(run_info_nc):

    """Read run info netcdf file, return a dictionary of all values"""

    logger.info(f'Reading run info file: {run_info_nc}')

    run_info_ds = xr.open_dataset(run_info_nc)

    run_info_dict = run_info_ds.to_dict()

    logger.debug(f'Run info dictionary: {run_info_dict}')

    return run_info_dict

def initialize_pysumma(summa_exe, file_manager):
    
    logger.info(f'Initializing pysumma')
 
    # Update start and end times
    sim = ps.Simulation(summa_exe, file_manager)
 
    return sim

def update_pysumma_with_runinfo(run_info_dict, summa_exe, file_manager, cwd):
    
    logger.info(f'Initializing pysumma')
 
    # Update start and end times
    sim = ps.Simulation(summa_exe, file_manager)
 
    start_time_datetime = run_info_dict['data_vars']['start_time']['data']
    end_time_datetime = run_info_dict['data_vars']['end_time']['data']

    start_time_str = start_time_datetime.strftime('%Y-%m-%d %H:%M:%S')
    end_time_str = end_time_datetime.strftime('%Y-%m-%d %H:%M:%S')

    logger.info(f'Updating model simulation start time to {start_time_str}')
    logger.info(f'Updating model simulation end time to {end_time_str}')

    sim.manager['simStartTime'] = start_time_str
    sim.manager['simEndTime'] = end_time_str

    settings_path = os.path.join(cwd, 'settings\\')
    forcing_path = os.path.join(cwd, 'input\\')
    output_path = os.path.join(cwd, 'output\\')

    logger.info(f'Updating settings path to {settings_path}')
    logger.info(f'Updating forcing path to {forcing_path}')
    logger.info(f'Updating output path to {output_path}')

    sim.manager['settingsPath'] = settings_path
    sim.manager['forcingPath'] = forcing_path
    sim.manager['outputPath'] = output_path

    return sim

def update_forcing_file(run_info_dict):

    logger.info('Beginning update of the forcing input file')

    input_netcdf_str = run_info_dict['data_vars']['input_netcdf_files']['data'][0].decode('utf-8')
    input_netcdf_path = Path(input_netcdf_str).resolve()

    logger.info(f'Updating forcing file {input_netcdf_path}')

    # Open the file
    ds = xr.open_dataset(input_netcdf_path)

    # Rename the 'stations' dimension to 'hru'
    ds = ds.rename({'stations': 'hru'})

    # Add a new variable 'data_step' with a scalar value of 3600 (data step length in seconds)
    # Update the description to be the 'long_name' and add units
    ds['data_step'] = xr.DataArray(3600, attrs={'long_name': 'data step length in seconds', 'units': 's'})

    # Rename variables 'x' and 'y' to 'latitude' and 'longitude'
    if 'lat' in ds and 'lon' in ds:
        ds = ds.rename({'x': 'latitude', 'y': 'longitude'})


    if 'station_id' in ds:
        ds = ds.rename({'station_id': 'hruId'})

        # Decoding each element if they are byte strings
        if isinstance(ds['hruId'].values[0], bytes):
            hruId_values = np.array([x.decode() for x in ds['hruId'].values])
        else:
            hruId_values = ds['hruId'].values

        # Convert the string array to a float array
        float_values = np.array(hruId_values, dtype=np.float32)

        # Then convert the float array to an integer array
        int_values = np.array(float_values, dtype=np.int32)

        ds['hruId'] = int_values

    # Dictionary to map existing variables to CF standard names, long names, and units
    cf_conventions = {
        'pptrate': {'standard_name': 'precipitation_flux', 'long_name': 'Precipitation Rate', 'units': 'kg m-2 s-1'},
        'airtemp': {'standard_name': 'air_temperature', 'long_name': 'Air Temperature', 'units': 'K'},
        'SWRadAtm': {'standard_name': 'downwelling_shortwave_flux_in_air', 'long_name': 'Downwelling Shortwave Radiation', 'units': 'W m-2'},
        'LWRadAtm': {'standard_name': 'downwelling_longwave_flux_in_air', 'long_name': 'Downwelling Longwave Radiation', 'units': 'W m-2'},
        'airpres': {'standard_name': 'air_pressure', 'long_name': 'Air Pressure', 'units': 'Pa'},
        'spechum': {'standard_name': 'specific_humidity', 'long_name': 'Specific Humidity', 'units': 'kg kg-1'},
        'windspd': {'standard_name': 'wind_speed', 'long_name': 'Wind Speed', 'units': 'm s-1'}
    }

    # Apply the CF conventions to the variables
    for var in cf_conventions:

        if var in ds:
            # Perform unit conversions if necessary
            if var == 'airtemp' and ds[var].attrs.get('units', '').lower() == 'oc':
                # Convert from Celsius to Kelvin
                ds[var] = ds[var] + 273.15
                ds[var].attrs['units'] = 'K'

            if var == 'airpres' and ds[var].attrs.get('units', '').lower() == 'kpa':
                # Convert from kPa to Pa
                ds[var] = ds[var] * 1000
                ds[var].attrs['units'] = 'Pa'

            if var == 'pptrate':
                # Convert from mm/s to kg/m2/s
                ds[var] = ds[var] * 0.001
                ds[var].attrs['units'] = 'kg m-2 s-1'

            ds[var].attrs.update(cf_conventions[var])

    # Remove all coordinates
    for var in list(ds.data_vars):
        data_array = ds[var].reset_coords(drop=True)
        ds[var] = data_array

    # Remove all variables that are not data variables
    variables_to_remove = ['lat', 'lon', 'x','y','z', 'station_names']  
    ds = ds.drop_vars([var for var in variables_to_remove if var in ds.variables])

    # Update encoding 
    ds.time.encoding['units'] = 'seconds since 1970-01-01 00:00:00'

    # To replace part of the filename
    updated_filename = str(input_netcdf_path.name).replace('.nc', '_summa.nc')
    updated_file_path = input_netcdf_path.with_name(updated_filename)

    logger.info(f'Writing updated forcing file to {updated_file_path}')

    # Write the updated file
    ds.to_netcdf(updated_file_path)

    return updated_file_path

def post_process_output(output_ds, cwd):

    # List of variables to be removed
    vars_to_remove = ['hru','hruId','gru', 'gruId']

    # Convert HRU IDs to a data type similar to the second file
    hru_ids = output_ds['hruId'].values
    hru_id_obj = hru_ids.astype('str')

    # Remove variables if they exist
    for var in vars_to_remove:
        if var in output_ds.variables:
            output_ds = output_ds.drop_vars(var)

    # Creating a dummy dataset for demonstration
    ds = xr.Dataset({
        "HRU_ID": ("ndata", hru_id_obj)
    })

    # Aligning dimensions and coordinates
    data_aligned = output_ds.rename({'hru': 'ndata'})
    #data_aligned['ndata'] = ds['HRU_ID']

    # Merging datasets
    merged_ds = xr.merge([data_aligned, ds])

    # Adding global attributes similar to the second file
    merged_ds.attrs['Conventions'] = 'CF-1.6'
    merged_ds.attrs['featureType'] = 'timeSeries'

    merged_ds['HRU_ID'].attrs['cf_role'] = 'timeseries_id'
    merged_ds['HRU_ID'].attrs['units'] = '1'
    merged_ds['HRU_ID'].attrs['coordinates'] = 'HRU_ID'
    merged_ds['HRU_ID'].attrs['long_name'] = 'ID of HRU'
    output_nc = Path(cwd, 'output\\summa_output.nc')
    
    # Save the modified dataset
    merged_ds.to_netcdf(output_nc)

def main():

    """Main function to run state update process"""

    # Read and assign all command line arguments and log
    cmd_line_args = get_command_line_agruments()
    cmd_options, _ = cmd_line_args.parse_args()

    # Resolve input arguments to absolute paths
    cwd = cmd_options.work_dir
    run_info_nc = Path(cmd_options.run_info_file).resolve()
    summa_exe = Path(cmd_options.summa_exe).resolve()
    file_manager = Path(cmd_options.file_manager).resolve()
    
    """Below the paths can be set manually for testing"""
    #cwd = "C:\\GitHub\\Deltares\\summa_run_test\\"
    #summa_exe = "C:\\GitHub\\Deltares\\summa_run_test\\bin\summa.exe"
    #file_manager = "C:\\GitHub\\Deltares\\summa_run_test\\Bow\\settings\\fileManager.txt"
    #run_info_nc = Path('C:\\GitHub\\Deltares\\summa_run_test\\Bow\\run_info.nc')

    setup_logger(cwd)

    logger.info(f'Beginning summa model run from Delft-FEWS')
    logger.info(f'Using command line options: {cmd_options}')

    #Read run info file into dictionary
    run_info_dict = read_run_info_file(run_info_nc)

    # Update forcing file to SUMMA format
    updated_forcing_file = update_forcing_file(run_info_dict)
    
    # Initiate pysumma with run info netcdf
    sim = update_pysumma_with_runinfo(run_info_dict, summa_exe, file_manager, cwd)

    # Run pysumma
    logger.info(f'Running SUMMA model')

    sim.run()

    logger.info(f'SUMMA model status is = {sim.status}')

    post_process_output(sim.output, cwd)

    return

if __name__ == "__main__":
   
   main()
