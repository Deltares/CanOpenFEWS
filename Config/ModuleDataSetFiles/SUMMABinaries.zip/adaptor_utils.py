import os
import optparse as op
import xarray as xr
import logging

logger = logging.getLogger(__name__)

def setup_logger(cwd, log_file_name='summa_model_run.log'):
    """
    Set local log file and formatting. This function initializes a global logger
    that can be used across the entire module.
    """
    global logger

    log_file = os.path.join(cwd, log_file_name)

    # Clear existing handlers if any
    if logger.hasHandlers():
        logger.handlers.clear()

    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # Stream Handler for printing logs to console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)


    logger.addHandler(file_handler)
    logger.info(f'Log file saved to {log_file}')

def get_command_line_agruments():
    '''Function to retrieve command line arguments'''

    logger.info('Reading command lines arguments')

    cmd_line_args = op.OptionParser()
    cmd_line_args.add_option('--work-dir',        '-d',  default = os.path.dirname(os.path.abspath(__file__)))
    cmd_line_args.add_option('--run-info-file',   '-r',  default ='./run_info.nc')

    # Read summa
    cmd_line_args.add_option('--summa-exe',       '-s',  default ='../bin/summa.exe')
    cmd_line_args.add_option('--model-exe',       '-m',  default ='../bin/mizuroute.exe')
    cmd_line_args.add_option('--file-manager',    '-f',  default ='./settings/fileManager.txt')

    return cmd_line_args

def read_run_info_file(run_info_nc):

    """Read run info netcdf file, return a dictionary of all values"""

    logger.info(f'Reading run info file: {run_info_nc}')

    run_info_ds = xr.open_dataset(run_info_nc)

    run_info_dict = run_info_ds.to_dict()

    logger.debug(f'Run info dictionary: {run_info_dict}')

    return run_info_dict