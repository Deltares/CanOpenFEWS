fileConn<-file("output.txt")
writeLines(c("You are running R from FEWS"," A brand new Hello World", "A brand new place I never knew"), fileConn)
close(fileConn)

