### START SCRIPT ###

## collect arguments from command line
args = commandArgs(trailingOnly=TRUE)
lib_loc <- args[1]
output_file <- args[2]
stn_file <- args[3]
output_folder <- args[4]
hydat_path <- args[5]

## hardcoded arguments
# start_date <- "2002-01-01" # uncomment for testing
# end_date <- "2002-01-10"   # uncomment for testing
timezone <- "GMT"

## start message thread for FEWS
fc<-file(output_file, open='w+')

writeLines("DEBUG - Initializing DownloadHydrometricData.R log", fc)

## setup library paths
.libPaths(lib_loc)
writeLines(sprintf("DEBUG - .libPaths are: %s", paste(.libPaths(), collapse="\n")), fc)
writeLines(sprintf("DEBUG - lib_loc is: %s",lib_loc), fc)

writeLines(sprintf("DEBUG - hydat_path is: %s",hydat_path), fc)

writeLines(sprintf("DEBUG - output_folder is: %s",output_folder), fc)


## check if hydat_path exists and has a database
if (!dir.exists(hydat_path)) {
  writeLines(sprintf("ERROR - %s","hydat_path folder does not exist, please run the 'Download or Update HYDAT database workflow'."), fc)
  close(fc)
  return(FALSE)
}

hydat_db <- file.path(hydat_path, "Hydat.sqlite3")
writeLines(sprintf("DEBUG - hydat_db is: %s",hydat_db), fc)

if (!file.exists(file.path(hydat_path, "Hydat.sqlite3"))) {
  writeLines(sprintf("ERROR - %s","hydat database not found in hydat_path, please run the 'Download or Update HYDAT database workflow'."), fc)
  close(fc)
  return(FALSE)
}

writeLines(sprintf("DEBUG - Loading required libraries..."), fc)

result <- tryCatch(
  {
    library(ncdf4, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(dplyr, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(tidyhydat, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(lubridate, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - Libraries loaded..."), fc)


writeLines(sprintf("DEBUG - Reading run_info.nc and determining download periods..."), fc)

# read in run_info.nc and store into R
result <- tryCatch(
  {
    nc <- nc_open("run_info.nc")
    # nc <- nc_open("work/run_info.nc")
    end_time <- ncdf4::ncvar_get(nc, "end_time")
    log_level <- ncdf4::ncvar_get(nc, "log_level")
    # properties <- ncdf4::ncvar_get(nc, "properties") # causes an error for some reason
    properties <- NA
    start_time <- ncdf4::ncvar_get(nc, "start_time")
    time_units <- ncatt_get(nc, "start_time")$units
    time0 <- ncdf4::ncvar_get(nc, "time0")
    work_dir <- ncdf4::ncvar_get(nc, "work_dir")
    nc_close(nc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - reading run_info.nc: %s",as.character(cond)), fc)
    close(fc)
    nc_close(nc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - reading run_info.nc: %s",as.character(cond)), fc)
  }
)

# read in run_info.nc and store into R
result <- tryCatch(
  {
    temp <- unlist(strsplit(time_units, split=" "))
    if (temp[1] != "minutes") {
      writeLines(sprintf("ERROR - issue reading netcdf file, format not in minutes after date"), fc)
      close(fc)
      return(FALSE)
    } 
    # calculate start and end date    
    start_date <- lubridate::as_datetime(paste(temp[3], temp[4]), tz=timezone)
    end_date <- start_date + lubridate::minutes(end_time)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - calculating start/end time: %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - calculating start/end time: %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - start_date is %s, end_date is %s", start_date, end_date),fc)


writeLines(sprintf("DEBUG - Reading station list %s", stn_file), fc)

result <- tryCatch(
  {
    stn_list <- read.csv(stn_file)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - Successfully read station list..."), fc)

# writeLines(sprintf("DEBUG - station list includes:\n%s", paste(stn_list$ID, collapse="\n")), fc)


## create output folder if it does not exist
result <- tryCatch(
  {
    if (!dir.exists(output_folder)) {
      dir.create(output_folder)
    }
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

## download daily data with tidyhydat, write to file
for (stn in stn_list$ID) {
  result <- tryCatch(
    {
      
      # writeLines(sprintf("DEBUG - now downloading data for station %s",stn), fc)
      
      # can update this to check if flow/level data exists at station for the specified period      
      dd <- tidyhydat::hy_daily(station_number=stn,
                                      start_date=as.Date(start_date),
                                      end_date=as.Date(end_date),
                                      hydat_path=hydat_db)
      
      # writeLines(sprintf("DEBUG - Writing stn %s data to file %s",stn, sprintf("%s/%s_historical_daily_flow.csv",output_folder,stn)), fc)
      # writeLines(sprintf("DEBUG - nrow dd is %i",nrow(dd)), fc)
      
      if ("Flow" %in% dd$Parameter) {
        dd[dd$Parameter == "Flow",] %>% 
          select(Date,Value,Symbol) %>% 
          write.csv(sprintf("%s/%s_historical_daily_flow.csv",output_folder,stn),
                    quote=FALSE, row.names=FALSE)
      } else {
        writeLines(sprintf("DEBUG - No historical daily flow data found for station %s",stn), fc)
      }
      
      if ("Level" %in% dd$Parameter) {
        dd[dd$Parameter == "Level",] %>% 
          select(Date,Value,Symbol) %>% 
          write.csv(sprintf("%s/%s_historical_daily_level.csv",output_folder,stn),
                    quote=FALSE, row.names=FALSE)
      } else {
        writeLines(sprintf("DEBUG - No historical daily level data found for station %s",stn), fc)
      }
      
      # writeLines(sprintf("DEBUG - result of file.exists(%s) is %s",sprintf("%s/%s_historical_daily_flow.csv",output_folder,stn), file.exists(sprintf("%s/%s_historical_daily_flow.csv",output_folder,stn)) ), fc)
      # writeLines(sprintf("DEBUG - result of file.exists(%s) is %s",sprintf("%s/%s_historical_daily_level.csv",output_folder,stn), file.exists(sprintf("%s/%s_historical_daily_level.csv",output_folder,stn)) ), fc)
      
    },
    error=function(cond) {
      message(cond)
      writeLines(sprintf("DEBUG - (converted from err) Historical daily data for %s NOT downloaded successfully: %s",stn,as.character(cond)), fc)
    },
    warning=function(cond) {
      message(cond)
      writeLines(sprintf("DEBUG - (converted from warning) Possible issue downloading historical daily data for %s: %s",stn,as.character(cond)), fc)
    }
  )
}

## wrap up
writeLines(sprintf("INFO - DownloadHistoricalHydrometricData Rscript finished"), fc)
close(fc)
