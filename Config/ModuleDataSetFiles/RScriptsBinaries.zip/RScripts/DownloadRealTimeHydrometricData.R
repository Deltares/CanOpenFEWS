### START SCRIPT ###

## collect arguments from command line
args = commandArgs(trailingOnly=TRUE)
lib_loc <- args[1]
output_file <- args[2]
stn_file <- args[3]
output_folder <- args[4]

## hardcoded arguments - credentials
WS_USRNM = "nt_partner"
WS_PWD = "0128!Nt2016"

## hardcoded arguments
timezone <- "GMT"
params_realtime <- c(46, 47) # NULL is fine too, takes all
# end_date <- Sys.Date()
# start_date <- end_date-30

## start message thread for FEWS
fc<-file(output_file, open='w+')

writeLines("DEBUG - Initializing DownloadHydrometricData.R log", fc)

## setup library paths
.libPaths(lib_loc)
writeLines(sprintf("DEBUG - .libPaths are: %s", paste(.libPaths(), collapse="\n")), fc)
writeLines(sprintf("DEBUG - lib_loc is: %s",lib_loc), fc)

writeLines(sprintf("DEBUG - output_folder is: %s",output_folder), fc)


writeLines(sprintf("DEBUG - Loading required libraries..."), fc)

result <- tryCatch(
  {
    library(ncdf4, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(dplyr, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(tidyhydat, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(tidyhydat.ws, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - Libraries loaded..."), fc)



writeLines(sprintf("DEBUG - Reading run_info.nc and determining download periods..."), fc)

# read in run_info.nc and store into R
result <- tryCatch(
  {
    nc <- nc_open("run_info.nc")
    # nc <- nc_open("work/run_info.nc")
    end_time <- ncdf4::ncvar_get(nc, "end_time")
    log_level <- ncdf4::ncvar_get(nc, "log_level")
    # properties <- ncdf4::ncvar_get(nc, "properties") # causes an error for some reason
    properties <- NA
    start_time <- ncdf4::ncvar_get(nc, "start_time")
    time_units <- ncatt_get(nc, "start_time")$units
    time0 <- ncdf4::ncvar_get(nc, "time0")
    work_dir <- ncdf4::ncvar_get(nc, "work_dir")
    nc_close(nc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - reading run_info.nc: %s",as.character(cond)), fc)
    close(fc)
    nc_close(nc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - reading run_info.nc: %s",as.character(cond)), fc)
  }
)

# read in run_info.nc and store into R
result <- tryCatch(
  {
    temp <- unlist(strsplit(time_units, split=" "))
    if (temp[1] != "minutes") {
      writeLines(sprintf("ERROR - issue reading netcdf file, format not in minutes after date"), fc)
      close(fc)
      return(FALSE)
    } 
    # calculate start and end date    
    start_date <- lubridate::as_datetime(paste(temp[3], temp[4]), tz=timezone)
    end_date <- start_date + lubridate::minutes(end_time)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - calculating start/end time: %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - calculating start/end time: %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - start_date is %s, end_date is %s", start_date, end_date),fc)



writeLines(sprintf("DEBUG - Reading station list %s...", stn_file), fc)

result <- tryCatch(
  {
    stn_list <- read.csv(stn_file)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - Successfully read station list..."), fc)

# writeLines(sprintf("DEBUG - station list includes: %s", paste(stn_list$ID, collapse="\n")), fc)


## create output folder if it does not exist
result <- tryCatch(
  {
    if (!dir.exists(output_folder)) {
      dir.create(output_folder)
    }
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)


## set tidyhydat.ws access token
writeLines(sprintf("DEBUG - Setting tidyhydat.ws token..."), fc)

result <- tryCatch(
  {
    Sys.setenv("WS_USRNM"=WS_USRNM)
    Sys.setenv("WS_PWD"=WS_PWD)
    token_out <- tidyhydat.ws::token_ws()
  },
  error=function(cond) {
    message(cond)
    writeLines(sprintf("ERROR - Creating tidyhydat.ws access token failed: %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    message(cond)
    writeLines(sprintf("WARNING - Possible issue creating tidyhydat.ws access token: %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("DEBUG - tidyhydat.ws access token created successfully"), fc)


## download realtime data with tidyhydat.ws, write to file
for (stn in stn_list$ID) {
  result <- tryCatch(
    {
      # can update this to check if flow/level data exists at station for the specified period      
      dd <- tidyhydat.ws::realtime_ws(
        station_number=stn,
        parameters=params_realtime,
        start=start_date,
        end=end_date,
        token=token_out
      )
      
      if (47 %in% dd$Parameter) {
        dd[dd$Parameter == 47,] %>% 
          select(Date,Value,Symbol,Parameter,Unit) %>% 
          write.csv(sprintf("%s/%s_realtime_flow.csv",output_folder,stn),
                    quote=FALSE, row.names=FALSE)
      } else {
        writeLines(sprintf("DEBUG - No realtime flow data found for station %s",stn), fc)
      }
      
      if (46 %in% dd$Parameter) {
        dd[dd$Parameter == 46,] %>% 
          select(Date,Value,Symbol,Parameter,Unit) %>% 
          write.csv(sprintf("%s/%s_realtime_level.csv",output_folder,stn),
                    quote=FALSE, row.names=FALSE)
      } else {
        writeLines(sprintf("DEBUG - No realtime level data found for station %s",stn), fc)
      }
      
    },
    error=function(cond) {
      message(cond)
      writeLines(sprintf("DEBUG - (converted from err) Realtime data for %s NOT downloaded successfully: %s",stn,as.character(cond)), fc)
    },
    warning=function(cond) {
      message(cond)
      writeLines(sprintf("DEBUG - (converted from warning) Possible issue downloading realtime data for %s: %s",stn,as.character(cond)), fc)
    }
  )
}

## wrap up
writeLines(sprintf("INFO - DownloadRealTimeHydrometricData Rscript finished"), fc)
close(fc)
