### START SCRIPT ###

## collect arguments from command line
args = commandArgs(trailingOnly=TRUE)
lib_loc <- args[1]
output_file <- args[2]

## hardcoded arguments
force_update <- FALSE # force reinstallation of all packages

## start message thread for FEWS
fc<-file(output_file, open='w+')

writeLines("DEBUG - Initializing InstallUpdateRLibraries.R log", fc)

## setup library paths
# .libPaths( c(.libPaths(), lib_loc))
.libPaths(lib_loc)
writeLines(sprintf("DEBUG - .libPaths are: %s", paste(.libPaths(), collapse="\n")), fc)
writeLines(sprintf("DEBUG - lib_loc is: %s",lib_loc), fc)


## set options for installations
options(install.packages.compile.from.source = "always")


## install packages if not found
### can add additional ones to this list as needed
pkglist <-  c("scales","magrittr","quantmod","Quandl",
              "PerformanceAnalytics","munsell","extraDistr","gtable","trend",
              "dplyr","dbplyr","RSQLite","lubridate",
              "readr","rlang","httr","ncdf4", "ggplot2",
              "tidyquant", "mblm","Kendall",
              "vctrs","memoise","DBI","tibble",
              "Rcpp","R6","rappdirs",
              "lifecycle","curl","blob","assertthat","hms",
              "readr","tzdb","vroom","tidyr","fasstr",
              "labeling","farver","xts",
              
              
              # knitr related required packages:
              "base64enc","digest","evaluate","highr","htmltools",
              "jsonlite","knitr","rmarkdown","mime","markdown","stringi",
              "stringr","tinytex","xfun","yaml"
              )

for (pkg in pkglist) {
  if (!(pkg %in% rownames(installed.packages(lib.loc=lib_loc))) | force_update) {
    writeLines(sprintf("Installing package %s to %s",pkg,lib_loc), fc)
    result <- tryCatch(
      {
        install.packages(pkg, lib=lib_loc, repos = "http://cran.us.r-project.org")
      },
      error=function(cond) {
        writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
        close(fc)
        return(FALSE)
      },
      warning=function(cond) {
        writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
      }
    )
  } else {
    writeLines(sprintf("DEBUG - Package %s found at %s",pkg,lib_loc), fc)
  }
}

if (!("tidyhydat" %in% rownames(installed.packages(lib.loc=lib_loc))) | force_update) {
  
  writeLines(sprintf("DEBUG - Installing package tidyhydat (from ropensci) to %s", lib_loc), fc)
  result <- tryCatch(
    {
      install.packages("tidyhydat", lib=lib_loc, repos = "https://dev.ropensci.org")
    },
    error=function(cond) {
      writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
      close(fc)
      return(FALSE)
    },
    warning=function(cond) {
      writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
    }
  )
} else {
  writeLines(sprintf("DEBUG - Package tidyhydat found at %s",lib_loc), fc)
}

if (!("tidyhydat.ws" %in% rownames(installed.packages(lib.loc=lib_loc))) | force_update) {
  writeLines(sprintf("DEBUG - Installing package tidyhydat.ws to %s", lib_loc), fc)
  result <- tryCatch(
    {
      install.packages("tidyhydat.ws", lib=lib_loc, repos='https://bcgov.github.io/drat/')
    },
    error=function(cond) {
      writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
      close(fc)
      return(FALSE)
    },
    warning=function(cond) {
      writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
    }
  )
} else {
  writeLines(sprintf("DEBUG - Package tidyhydat.ws found at %s",lib_loc), fc)
}

## wrap up
writeLines(sprintf("INFO - InstallUpdateRLibraries Rscript complete"), fc)
close(fc)
