### START SCRIPT ###

## collect arguments from command line
args = commandArgs(trailingOnly=TRUE)
lib_loc <- args[1]
output_file <- args[2]
hydat_path <- args[3]

## hardcoded arguments

## temporary
# hydat_path <- "d:/Documents/Heron_Hydrologic/Projects/00003_GNWT_Deltares/03_Technical/repo/FEWS_NWT/Import/HYDATDB"
# output_file <- "output_temp.txt"
# lib_loc <- "d:/Documents/Heron_Hydrologic/Projects/00003_GNWT_Deltares/03_Technical/repo/FEWS_NWT/Modules/R-4.1.1/library/"

## start message thread for FEWS
fc<-file(output_file, open='w+')

writeLines("DEBUG - Initializing DownloadUpdateHYDAT.R log", fc)

## setup library paths
# .libPaths( c(.libPaths(), lib_loc))
.libPaths(lib_loc)
writeLines(sprintf("DEBUG - .libPaths are: %s", paste(.libPaths(), collapse="\n")), fc)
writeLines(sprintf("DEBUG - lib_loc is: %s",lib_loc), fc)

writeLines(sprintf("DEBUG - hydat_path is: %s",hydat_path), fc)

writeLines(sprintf("DEBUG - Loading required libraries..."), fc)

result <- tryCatch(
  {
    library(ncdf4, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(tidyhydat, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

result <- tryCatch(
  {
    library(tidyhydat.ws, lib.loc=lib_loc)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("Libraries loaded..."), fc)

## read in run_info.nc and store into R 
# nc <- nc_open("work/run_info.nc")
# end_time <- ncdf4::ncvar_get(nc, "end_time")
# log_level <- ncdf4::ncvar_get(nc, "log_level")
# # properties <- ncdf4::ncvar_get(nc, "properties") # causes an error for some reason
# properties <- NA
# start_time <- ncdf4::ncvar_get(nc, "start_time")
# time0 <- ncdf4::ncvar_get(nc, "time0")
# work_dir <- ncdf4::ncvar_get(nc, "work_dir")


## download or update HYDAT (updated version from ropensci that does not require keypress)
result <- tryCatch(
  {
    tidyhydat::download_hydat(dl_hydat_here = hydat_path, ask=FALSE)
  },
  error=function(cond) {
    writeLines(sprintf("ERROR - HYDAT database not successfully updated: %s",as.character(cond)), fc)
    close(fc)
    return(FALSE)
  },
  warning=function(cond) {
    writeLines(sprintf("WARNING - HYDAT database may not have updated successfully: %s",as.character(cond)), fc)
  }
)

writeLines(sprintf("INFO - DownloadUpdateHYDAT Rscript finished, HYDAT written to %s", hydat_path), fc)
close(fc)
