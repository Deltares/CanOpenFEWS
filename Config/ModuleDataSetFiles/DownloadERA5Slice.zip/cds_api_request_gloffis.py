# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 21:14:18 2019

@author: weerts
"""
import cdsapi
import os
import sys
import datetime

print("modules imported")

T0=sys.argv[1]
end = datetime.datetime.strptime(T0, "%Y%m%d")
start=end-datetime.timedelta(days=7) 
date_generated = [start + datetime.timedelta(days=x) for x in range(0, (end-start).days)]

print(start, end)

for date in date_generated:
	c = cdsapi.Client()
    
	c.retrieve(
	    'reanalysis-era5-single-levels',
	    {
		'product_type':'reanalysis',
		'variable':[
		    '2m_temperature','mean_sea_level_pressure','potential_evaporation',
		    'surface_pressure','surface_solar_radiation_downwards','toa_incident_solar_radiation',
		    'total_precipitation'
		],
		'year':date.year,
		'month':date.month,
		'day': date.day
		,
		'time':[
		    '00:00','01:00','02:00',
		    '03:00','04:00','05:00',
		    '06:00','07:00','08:00',
		    '09:00','10:00','11:00',
		    '12:00','13:00','14:00',
		    '15:00','16:00','17:00',
		    '18:00','19:00','20:00',
		    '21:00','22:00','23:00'
		],
		'format':'netcdf'
	    },
	    'download_'+date.strftime('%Y%m%d')+'.nc')