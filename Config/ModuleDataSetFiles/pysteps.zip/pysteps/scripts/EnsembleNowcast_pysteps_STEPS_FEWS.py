# -*- coding: utf-8 -*-

"""
Ruben Imhoff (Deltares)

Ensemble nowcast with pySTEPS' STEPS model based on a netCDF input from 
Delft-FEWS and run metadata as provided by an XML file from FEWS. Files 
are saved as netCDF with the forecast rainfall intensities (mm/h).

pysteps version 1.7.4 is used as basis for these nowcasts. The original code 
has been adjusted to import and handle the input netCDF files from Delft-FEWS.

For more info about pysteps: https://pysteps.github.io/

To run this script locally, change: 
    indir - the input directory
"""

import os
import datetime
import netCDF4
import numpy as np
import pprint
import sys
import time

start_time_script = time.time()

import pysteps
import pysteps.io
import pysteps.motion
import pysteps.nowcasts
import pysteps.utils

from xml_reader import ReadXML

cwd = os.getcwd()
work_dir = os.path.dirname(cwd)


# --------------------------------------------------------------------------- #
# The given arguments from the xml file
# --------------------------------------------------------------------------- #

# Get the run settings:
startdate_xml, ens_mem_xml, fc_length_xml, num_cores_xml, radar_data_name = ReadXML.read_settings_xml_nowcast_only(os.path.join(work_dir,"Input","radar_nowcast_settings.xml"))


# --------------------------------------------------------------------------- #
# Initial settings
# --------------------------------------------------------------------------- #

data_source = "eccc_bow"

pysteps_version = "1.7.4"

# The experiment set-up - this includes tuneable parameters
experiment_settings = {
    # Set the start time
    "starttime"         : startdate_xml,
    
    # forecast settings
    "n_lead_times"      : int(fc_length_xml*10),# Timesteps per nowcast (30 = 3 hour lead time). *10 to go from hours to 6-min steps in the lead time.
    "r_threshold"       : 0.1,                  # rain/no rain threshold [mm/h]
    "unit"              : "mm/h",               # output unit mm/h or dBZ (this is not the unit of the input data, that's defined in the importer)
    "transformation"    : "dB",                 # None or dB (more options nowadays, see the ReadTheDocs)
    "adjust_domain"     : None,                 # None or square
    "n_ens_members"     : ens_mem_xml,          # Number of ensemble members           
    "ar_order"          : 2,                    # Generally 2
    "n_cascade_levels"  : 8,                    # Generally 8, 6 for S-PROG
    "buffer_mask"       : 10,                   # The buffer mask (in no. of pixels) used in the optical flow method
    
    # the methods
    "oflow_method"      : "lucaskanade",        # e.g. lucaskanade, darts
    "adv_method"        : "semilagrangian",     # semilagrangian, eulerian
    "nwc_method"        : "steps",              # (Only option right now - anvil should be possible in the newest release)
    "noise_method"      : "nonparametric",      # parametric, nonparametric, ssft (better not to use parametric. ssft is better but about three times slower)
    "decomp_method"     : "fft",                # only fft as option at the moment
    "mask_method"       : "incremental",        # obs, incremental, sprog
    "prob_matching"     : "cdf",                # None, mean or cdf
    "noise_adjustment"  : "auto",               # {'auto','fixed',None}, optional
    "fft_method"        : "numpy",              # numpy is the only option at the moment
    "domain"            : "spatial",            # spatial or spectral
    "vel_pert_method"   : None,                 # Standard is 'bps', but recommend to turn it off.    
    "conditional"       : False,
    "precip_mask"       : True,
    
    # For saving and reproducibility
    "overwrite"         : True,                 # to recompute nowcasts
    "v_accu"            : None,                 # in [min]
    "seed"              : None,                 # Set to None for random seed, set to a number for reproducibility during testing
}


# --------------------------------------------------------------------------- #
# Get the correct paths
# --------------------------------------------------------------------------- #

# Set the location of the pysteps distribution
os.chdir(work_dir)

# Set the directory of the log files
logfile_dir = os.path.join(work_dir, "Logs")

# Get the correct paths
fn_pattern = radar_data_name
fn_ext = "nc"
importer_name = "eccc_bow_netcdf_fews"
importer_kwargs = {
                "accutime": 6,
                "qty": "ACRR",
			}
timestep = importer_kwargs["accutime"]

# Conditional parameters - parameters that can be directly related to other 
# parameters
def cond_pars(pars):
    for key in list(pars):
        if key == "oflow_method":
            if pars[key].lower() == "darts":  pars["n_prvs_times"] = 9 # For DARTS, more previous time steps are necessary
            else:                             pars["n_prvs_times"] = 3 # So, in total 4 radar images are used to construct the motion field. Perhaps good to place this in the inital settings at some point.
        elif key.lower() == "n_cascade_levels":
            if pars[key] == 1 : pars["bandpass_filter"] = "uniform"
            else:               pars["bandpass_filter"] = "gaussian"
        elif key.lower() == "nwc_method":
            if pars[key] == "extrapolation" : pars["n_ens_members"] = 1
    return pars
    
# Apply conditional parameters
experiment_settings = cond_pars(experiment_settings)
    
print("************************")
print("* Parameter set:")
print("************************")

pprint.pprint(experiment_settings)

# If necessary, build path to results
path_to_experiment = os.path.join(work_dir, "Output")
# subdir with event date
path_to_nwc = os.path.join(path_to_experiment)

try:
    os.makedirs(path_to_nwc)
except FileExistsError:
    pass

    
# --------------------------------------------------------------------------- #
# NOWCASTING
# --------------------------------------------------------------------------- #

if experiment_settings["v_accu"] is None:
    experiment_settings["v_accu"] = timestep

# Loop forecasts for given event
startdate = datetime.datetime.strptime(experiment_settings["starttime"], "%Y%m%d%H%M")
countnwc = 0

# Redirect stdout to log file
logfn =  os.path.join(logfile_dir, "%s_log.txt" % startdate.strftime("%Y%m%d%H%M")) 
print("Log: %s" % logfn)
orig_stdout = sys.stdout
f = open(logfn, 'w')
sys.stdout = f

try:
    # Filename of the nowcast netcdf
    outfn = os.path.join(path_to_nwc, "%s_nowcast.nc" % startdate.strftime("%Y%m%d%H%M"))

    # Check if results already exist
    run_exist = False
    if os.path.isfile(outfn):
        fid = netCDF4.Dataset(outfn, 'r')
        if fid.dimensions["time"].size == experiment_settings["n_lead_times"]:
            run_exist = True
            if experiment_settings["overwrite"]:
                os.remove(outfn)
                run_exist = False    
        else:
            os.remove(outfn)
            
    if run_exist:
        print("Nowcast %s_nowcast already exists in %s" % (startdate.strftime("%Y%m%d%H%M"),path_to_nwc))

    countnwc += 1
    print("Computing the nowcast (%02d) ..." % countnwc)
    
    print("Starttime: %s" % startdate.strftime("%Y%m%d%H%M"))
    
    print("The following run was requested:")
    print("startdate = ",startdate_xml)
    print("Number of ensemble members: ",str(ens_mem_xml))
    print("Forecast length: ",str(fc_length_xml))
    print("Number of cores used: ",str(num_cores_xml))

    print("*******************")
    print("* %s *****" % startdate.strftime("%Y%m%d%H%M"))
    print("* Parameter set : *")
    pprint.pprint(experiment_settings)
    print("*******************")
    
    print("--- Start of the run : %s ---" % (datetime.datetime.now()))
    print("Using pysteps version: ",pysteps_version)
    
    # Time
    t0 = time.time()

    # Read inputs
    print("Read the data...")
    
    # Find radar field filenames
    input_files = os.path.join(work_dir, "Input", fn_pattern+"."+fn_ext)
    
    # ---------------------------------------------------------------------- #
    # Read the radar data
    # ---------------------------------------------------------------------- #
    importer = pysteps.io.get_method(importer_name, "importer")
    print("Input file is: ",input_files)
    precip_radar, _, radar_metadata = pysteps.io.read_timeseries(
        input_files, 
        importer, 
        n_prvs_times=experiment_settings["n_prvs_times"], 
        importer_name = "eccc_bow_netcdf_fews", 
        startdate=startdate, 
        timestep=timestep, 
        **importer_kwargs,
    )
    
    # We flip R over the second axis (the rows) as it is saved upside down
    precip_radar = precip_radar[:, ::-1, :]
    
    metadata0 = radar_metadata.copy()
    metadata0["shape"] = precip_radar.shape[1:]
    
    print("Metadata is:")
    print(metadata0)
    
    # ---------------------------------------------------------------------- #
    # Prepare radar input files
    # ---------------------------------------------------------------------- #  
    print("Prepare the data...")
    
    # If requested, make sure we work with a square domain
    reshaper = pysteps.utils.get_method(experiment_settings["adjust_domain"])
    precip_radar, radar_metadata = reshaper(precip_radar, radar_metadata)

    # If necessary, convert to rain rates [mm/h]    
    converter = pysteps.utils.get_method("mm/h")
    precip_radar, radar_metadata = converter(precip_radar, radar_metadata)
    
    # Threshold the data
    precip_radar[precip_radar < experiment_settings["r_threshold"]] = 0.0
    radar_metadata["threshold"] = experiment_settings["r_threshold"]
    
    # Make sure that not all values are zero, otherwise only save zeroes
    if np.nansum(precip_radar) <= 0.0:
        print("Only zeroes found in the input, pysteps will not run and only output zero rainfall")
        def export(X):
            # export the zeroes to a netcdf
            pysteps.io.export_forecast_dataset(X, exporter)
        
        # Initialize netcdf file   
        exporter = pysteps.io.initialize_forecast_exporter_netcdf(
            outpath = path_to_nwc,
            outfnprefix = startdate.strftime("%Y%m%d%H%M")+"_nowcast",
            startdate = startdate,
            timestep = timestep,
            n_timesteps = experiment_settings["n_lead_times"],
            shape = metadata0["shape"],
            n_ens_members = experiment_settings["n_ens_members"],
            metadata = metadata0,
            incremental=None
        )
        
        # Save only zeroes
        if experiment_settings["n_ens_members"] > 1:
            pysteps.io.export_forecast_dataset(
                field=np.zeros((experiment_settings["n_ens_members"],
                                experiment_settings["n_lead_times"],
                                metadata0["shape"][0],
                                metadata0["shape"][1])),
                exporter=exporter
            )
        else:
            pysteps.io.export_forecast_dataset(
                field=np.zeros((experiment_settings["n_lead_times"],
                                metadata0["shape"][0],
                                metadata0["shape"][1])),
                exporter=exporter
            )    
        
    # If there is data in the observations, make a nowcast
    else:       
        # Transform the data
        transformer = pysteps.utils.get_method(
            experiment_settings["transformation"]
            )
        precip_radar, radar_metadata = transformer(
            precip_radar, radar_metadata, threshold=radar_metadata["threshold"]
            )
        
        # Compute motion field
        oflow_method = pysteps.motion.get_method(
            experiment_settings["oflow_method"]
            )
        # Also set the kwargs
        fd_kwargs2 = {"buffer_mask": experiment_settings["buffer_mask"]}
        uv_radar = oflow_method(precip_radar, fd_kwargs=fd_kwargs2)
        
        # ------------------------------------------------------------------- # 
        # Perform the nowcast       
        # ------------------------------------------------------------------- # 
        print("Pre-processing done - Start the nowcast")
        
        # Define the callback function to export the nowcast to netcdf (#TODO: place the function outside the loop)
        converter = pysteps.utils.get_method("mm")
        def export(X):
            # Convert to mm
            X,_ = converter(X, radar_metadata)
            # Readjust to initial domain shape
            X,_ = reshaper(X, radar_metadata, inverse=True)
            if X.shape[0] == 1:
                X = X[0,:,:]
            # export to netcdf
            pysteps.io.export_forecast_dataset(X, exporter)
        
        # Initialize netcdf file
        incremental = "timestep" if experiment_settings["nwc_method"].lower() == "steps" else None
        print("incremental = ",incremental)
    
        exporter = pysteps.io.initialize_forecast_exporter_netcdf(
            outpath = path_to_nwc,
            outfnprefix = startdate.strftime("%Y%m%d%H%M")+"_nowcast",
            startdate = startdate,
            timestep = timestep,
            n_timesteps = experiment_settings["n_lead_times"],
            shape = metadata0["shape"],
            n_ens_members = experiment_settings["n_ens_members"],
            metadata = metadata0,
            incremental=incremental
            )
        
        # Start the nowcast
        nwc_method = pysteps.nowcasts.get_method(
            experiment_settings["nwc_method"]
            )
        R_fct = nwc_method(
            precip=precip_radar[-3:, :, :],
            velocity=uv_radar,
            timesteps=experiment_settings["n_lead_times"],
            timestep=timestep,
            n_ens_members=experiment_settings["n_ens_members"],
            n_cascade_levels=experiment_settings["n_cascade_levels"],
            precip_thr=radar_metadata["threshold"],
            kmperpixel=1.0,
            extrap_method=experiment_settings["adv_method"],
            decomp_method=experiment_settings["decomp_method"],
            bandpass_filter_method=experiment_settings["bandpass_filter"],
            noise_method=experiment_settings["noise_method"],
            noise_stddev_adj=experiment_settings["noise_adjustment"],
            vel_pert_method=experiment_settings["vel_pert_method"],
            ar_order=experiment_settings["ar_order"],
            conditional=experiment_settings["conditional"],
            probmatching_method=experiment_settings["prob_matching"],
            mask_method=experiment_settings["mask_method"],
            callback=export,
            return_output=False,
            seed=experiment_settings["seed"],
            measure_time=False,
            num_workers=num_cores_xml,
            fft_method=experiment_settings["fft_method"],
            domain=experiment_settings["domain"],
            )
    
    # Save results
    pysteps.io.close_forecast_files(exporter)
    R_fct = None
    
    # Save log
    print("--- End of the run : %s ---" % (datetime.datetime.now()))
    print("--- Total time : %s seconds ---" % (time.time() - t0))
    sys.stdout = orig_stdout
    f.close()

except (ValueError, KeyError, IOError, IndexError) as e:
    print("Error during the nowcast: ", e)
    sys.stdout = orig_stdout
    f.close()
            
            
end = time.time()
print('Total process took', (end - start_time_script)/3600.0, 'hours')
