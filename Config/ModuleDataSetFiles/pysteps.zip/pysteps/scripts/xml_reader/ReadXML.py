# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 17:42:14 2021

@author: Ruben Imhoff (Deltares / Wageningen UR)

Function to read the xml settings from Delft-FEWS, which are used as initial
settings for radar rainfall nowcasting with pysteps.

The initial settings are used in the pysteps run script.

Functions:
    - read_settings_xml
    - read_settings_linear_blending_xml
    - read_settings_harmonie
    - read_settings_xml_nowcast_only
"""

import xml
from xml import dom
from xml.dom import minidom
import datetime
import os


# --------------------------------------------------------------------------- #
# The function
# --------------------------------------------------------------------------- #

def read_settings_xml(xml_file):
    """Function to read the xml settings from Delft-FEWS, which are used as 
    initial settings for radar rainfall nowcasting with pysteps.

    Parameters
    ----------
    xml_file: string
        The location and filename of the xml-file which contains the nowcast 
        settings for pysteps

    Returns
    -------
    startdate: string
        The startdate of the nowcast as %Y%m%d%H%M.
    ens_members: int
        The number of ensemble members for the run.
    fc_length: int
        The forecast length (forecast horizon) in number of time steps.
    num_cores: int
        The number of cores to be used. If > 1, the ensemble members will be 
        run in parallel.
    time_step_out: int
        The requested output temporal resolution in minutes.
    dir_nwp_data: str
        The directory where the disaggregated and decomposed NWP forecast should
        be stored.
    radar_data_name: str
        The name of the radar data file, generally IRC.nc. 
    """
    ###
    # Initial settings
    ###
    
    # Set the indir + filename of the used xml file
    input_xml = xml_file

    ###
    # Get the information from the xml
    ###
    
    # Open the xml
    doc = xml.dom.minidom.parse(input_xml)
    
    # Get the last observation date
    last_obs = doc.getElementsByTagName("time0")
    
    for value in last_obs:
        date = value.getAttribute("date")
        time = value.getAttribute("time")
        
    # Set the startdate in the right format (e.g. "201008262230")
    full_date = date + " " + time
    full_date_datetime = datetime.datetime.strptime(full_date, "%Y-%m-%d %H:%M:%S")
    startdate = full_date_datetime.strftime("%Y%m%d%H%M")
    
    # Also get the name of the input radar data
    radar_data_file = doc.getElementsByTagName("inputNetcdfFile")
    radar_data_name = os.path.basename(radar_data_file[0].firstChild.nodeValue).split(".")[0]
    
    # Get the integer properties
    properties = doc.getElementsByTagName("int")
    
    for prop in properties:
        # Get the ensemble members
        if prop.attributes["key"].value == "ensemble_members":
            ens_members = int(prop.getAttribute("value"))
        # Get the number of cores that are available
        if prop.attributes["key"].value == "num_cores" :
            num_cores = int(prop.getAttribute("value"))
        # Get the number of cores that are available
        if prop.attributes["key"].value == "timestep_minute":
            time_step_out = int(prop.getAttribute("value"))
        # Get the number of timesteps in the forecast (the forecast length)
        if prop.attributes["key"].value == "n_lead_times_hr" :
            n_lead_times_hr = int(prop.getAttribute("value"))
    fc_length = int(n_lead_times_hr * (60 / time_step_out))

    # Get the string properties
    properties = doc.getElementsByTagName("string")
    
    for prop in properties:
        # Get the original temporal resolution of the Harmonie forecast
        if prop.attributes["key"].value == "dir_nwp_data":
            dir_nwp_data = str(prop.getAttribute("value"))
                        

    return startdate, ens_members, fc_length, num_cores, time_step_out, dir_nwp_data, radar_data_name


def read_settings_linear_blending_xml(xml_file):
    """Function to read the xml settings from Delft-FEWS, which are used as 
    initial settings for radar rainfall nowcasting with pysteps.

    Parameters
    ----------
    xml_file: string
        The location and filename of the xml-file which contains the nowcast 
        settings for pysteps

    Returns
    -------
    startdate: string
        The startdate of the nowcast as %Y%m%d%H%M.
    ens_members: int
        The number of ensemble members for the run.
    fc_length: int
        The forecast length (forecast horizon) in number of time steps.
    num_cores: int
        The number of cores to be used. If > 1, the ensemble members will be 
        run in parallel.
    time_step_out: int
        The requested output temporal resolution in minutes.
    dir_nwp_data: str
        The directory where the disaggregated and decomposed NWP forecast should
        be stored.
    blending_method: str
        The blending method that should be used. Choice of "linear" and 
        "salient".
    radar_data_name: str
        The name of the radar data file, generally IRC.nc. 
    """
    ###
    # Initial settings
    ###
    
    # Set the indir + filename of the used xml file
    input_xml = xml_file

    ###
    # Get the information from the xml
    ###
    
    # Open the xml
    doc = xml.dom.minidom.parse(input_xml)
    
    # Get the last observation date
    last_obs = doc.getElementsByTagName("time0")
    
    for value in last_obs:
        date = value.getAttribute("date")
        time = value.getAttribute("time")
        
    # Set the startdate in the right format (e.g. "201008262230")
    full_date = date + " " + time
    full_date_datetime = datetime.datetime.strptime(full_date, "%Y-%m-%d %H:%M:%S")
    startdate = full_date_datetime.strftime("%Y%m%d%H%M")
    
    # Get the integer properties
    properties = doc.getElementsByTagName("int")
    
    for prop in properties:
        # Get the ensemble members
        if prop.attributes["key"].value == "ensemble_members":
            ens_members = int(prop.getAttribute("value"))
        # Get the number of cores that are available
        if prop.attributes["key"].value == "num_cores" :
            num_cores = int(prop.getAttribute("value"))
        # Get the number of cores that are available
        if prop.attributes["key"].value == "timestep_minute" :
            time_step_out = int(prop.getAttribute("value"))
        # Get the number of timesteps in the forecast (the forecast length)
        if prop.attributes["key"].value == "n_lead_times_hr" :
            n_lead_times_hr = int(prop.getAttribute("value"))
    fc_length = int(n_lead_times_hr * (60 / time_step_out))
            
    # Also get the name of the input radar data
    radar_data_file = doc.getElementsByTagName("inputNetcdfFile")
    radar_data_name = os.path.basename(radar_data_file[0].firstChild.nodeValue).split(".")[0]
            
    # Get the string properties
    properties = doc.getElementsByTagName("string")
    
    for prop in properties:
        # Get the original temporal resolution of the Harmonie forecast
        if prop.attributes["key"].value == "dir_nwp_data":
            dir_nwp_data = str(prop.getAttribute("value"))
        # Get the blending method
        if prop.attributes["key"].value == "blending_method":
            blending_method = str(prop.getAttribute("value"))                        

    return startdate, ens_members, fc_length, num_cores, time_step_out, dir_nwp_data, blending_method, radar_data_name


def read_settings_harmonie(xml_file):
    """Function to read the xml settings from Delft-FEWS, which are used as 
    initial settings for the disaggregation of the Harmonie NWP forecast to a
    finer temporal resolution.

    Parameters
    ----------
    xml_file: string
        The location and filename of the xml-file which contains the Harmonie
        disaggregation settings.

    Returns
    -------
    startdate: string
        The startdate of the nowcast as %Y%m%d%H%M.
    timestep_harmonie: int
        The time step (in minutes) used in the Harmonie NWP forecast.
    timestep_disaggregated: int
        The time step (in minutes) used for the disaggregated forecast.
    num_cores: int
        The number of cores to be used for the FFT decomposition. 
    n_lead_times: int
        The forecast length (forecast horizon) in number of hours. This indicates the 
        number of forecast lead times of the NWP forecast that are stored.
    dir_nwp_data: str
        The directory where the disaggregated and decomposed NWP forecast should
        be stored.
    nwp_data_name: str
        The name of the NWP forecast file, generally Harmonie.nc. 
    """
    ###
    # Initial settings
    ###
    
    # Set the indir + filename of the used xml file
    input_xml = xml_file

    ###
    # Get the information from the xml
    ###
    
    # Open the xml
    doc = xml.dom.minidom.parse(input_xml)
    
    # Get the last observation date
    last_obs = doc.getElementsByTagName("time0")
    
    for value in last_obs:
        date = value.getAttribute("date")
        time = value.getAttribute("time")
        
    # Set the startdate in the right format (e.g. "201008262230")
    full_date = date + " " + time
    full_date_datetime = datetime.datetime.strptime(full_date, "%Y-%m-%d %H:%M:%S")
    startdate = full_date_datetime.strftime("%Y%m%d%H%M")
    
    # Get the integer properties
    properties = doc.getElementsByTagName("int")
    
    for prop in properties:
        # Get the original temporal resolution of the Harmonie forecast
        if prop.attributes["key"].value == "timestep_harmonie":
            timestep_harmonie = int(prop.getAttribute("value"))
        # Get the requested disaggregated temporal resolution 
        if prop.attributes["key"].value == "timestep_disaggregated" :
            timestep_disaggregated = int(prop.getAttribute("value"))
        # Get the number of cores that are available
        if prop.attributes["key"].value == "num_cores" :
            num_cores = int(prop.getAttribute("value"))    
        # Get the number of lead tiems that should be stored
        if prop.attributes["key"].value == "n_lead_times_hr" :
            n_lead_times = int(prop.getAttribute("value"))  
            
    # Also get the name of the input radar data
    nwp_data_file = doc.getElementsByTagName("inputNetcdfFile")
    nwp_data_name = os.path.basename(nwp_data_file[0].firstChild.nodeValue).split(".")[0]

    # Get the string properties
    properties = doc.getElementsByTagName("string")
    
    for prop in properties:
        # Get the original temporal resolution of the Harmonie forecast
        if prop.attributes["key"].value == "dir_nwp_data":
            dir_nwp_data = str(prop.getAttribute("value"))
            
    return startdate, timestep_harmonie, timestep_disaggregated, num_cores, n_lead_times, dir_nwp_data, nwp_data_name
        

def read_settings_xml_nowcast_only(xml_file):
    """Function to read the xml settings from Delft-FEWS, which are used as 
    initial settings for radar rainfall nowcasting with pysteps.

    Parameters
    ----------
    xml_file: string
        The location and filename of the xml-file which contains the nowcast 
        settings for pysteps

    Returns
    -------
    startdate: string
        The startdate of the nowcast as %Y%m%d%H%M.
    ens_members: int
        The number of ensemble members for the run.
    n_lead_times_hr: int
        The forecast length (forecast horizon) in number of hours.
    num_cores: int
        The number of cores to be used. If > 1, the ensemble members will be 
        run in parallel.
    radar_data_name: str
        The name of the radar data file, generally IRC.nc. 
    """
    
    ###
    # Initial settings
    ###
    
    # Set the indir + filename of the used xml file
    input_xml = xml_file

    ###
    # Get the information from the xml
    ###
    
    # Open the xml
    doc = xml.dom.minidom.parse(input_xml)
    
    # Get the last observation date
    last_obs = doc.getElementsByTagName("time0")
    
    for value in last_obs:
        date = value.getAttribute("date")
        time = value.getAttribute("time")
        
    # Set the startdate in the right format (e.g. "201008262230")
    full_date = date + " " + time
    full_date_datetime = datetime.datetime.strptime(full_date, "%Y-%m-%d %H:%M:%S")
    startdate = full_date_datetime.strftime("%Y%m%d%H%M")
    
    # Also get the name of the input radar data
    radar_data_file = doc.getElementsByTagName("inputNetcdfFile")
    radar_data_name = os.path.basename(radar_data_file[0].firstChild.nodeValue).split(".")[0]
    
    # Get the properties
    properties = doc.getElementsByTagName("int")
    
    for prop in properties:
        # Get the ensemble members
        if prop.attributes["key"].value == "ensemble_members":
            ens_members = int(prop.getAttribute("value"))
        # Get the number of timesteps in the forecast (the forecast length)
        if prop.attributes["key"].value == "n_lead_times_hr" :
            n_lead_times_hr = int(prop.getAttribute("value"))
        # Get the number of cores that are available
        if prop.attributes["key"].value == "num_cores" :
            num_cores = int(prop.getAttribute("value"))
            
    return startdate, ens_members, n_lead_times_hr, num_cores, radar_data_name