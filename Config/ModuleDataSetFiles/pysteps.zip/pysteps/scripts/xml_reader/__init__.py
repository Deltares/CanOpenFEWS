# -*- coding: utf-8 -*-
"""
Created on Wed Jan  6 10:58:28 2021

@author: Ruben Imhoff (Deltares / Wageningen UR)

Method to import the pysteps run setting from a xml file that is parsed through
Delft-FEWS.
"""

from xml_reader.ReadXML import read_settings_xml, read_settings_linear_blending_xml, read_settings_harmonie, read_settings_xml_nowcast_only
