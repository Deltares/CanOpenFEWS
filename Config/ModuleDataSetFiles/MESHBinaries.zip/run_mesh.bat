sa_mesh_r1860 > screen_output.txt 2>&1
